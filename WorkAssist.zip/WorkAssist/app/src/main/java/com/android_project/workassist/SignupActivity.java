package com.android_project.workassist;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

@SuppressWarnings("ALL")
public class SignupActivity extends AppCompatActivity {

    Button b_signin, b_c_signup, b_m_signup;
    EditText et_pincode, et_work;
    TextView tv_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        int id_bms=R.id.b_member_signup, id_bcs=R.id.b_customer_signup;
        b_m_signup = findViewById(id_bms);
        b_c_signup = findViewById(id_bcs);
        et_pincode = findViewById(R.id.et_pincode);
        et_work = findViewById(R.id.et_work);
        tv_signup = findViewById(R.id.tv_signup);

        b_m_signup.setOnClickListener(view -> {
            changeSignin(b_m_signup, b_c_signup);
            et_pincode.setVisibility(View.VISIBLE);
            et_work.setVisibility(View.VISIBLE);
        });

        b_c_signup.setOnClickListener(view -> {
            changeSignin(b_c_signup, b_m_signup);
            et_pincode.setVisibility(View.GONE);
            et_work.setVisibility(View.GONE);
        });

        b_signin = findViewById(R.id.b_signin);
        b_signin.setOnClickListener(view -> {
            Intent i = new Intent(getApplicationContext(),SigninActivity.class);
            startActivity(i);
        });
    }

    @SuppressLint({"SetTextI18n", "UseCompatLoadingForColorStateLists"})
    public void changeSignin(Button a, Button b){
        if(a==findViewById(R.id.b_customer_signup))
            tv_signup.setText("Customer's SignUp");
        else
            tv_signup.setText("Member's SignUp");

        a.setBackgroundTintList(getApplicationContext().getResources().getColorStateList(R.color.teal_200));
        a.setTextColor(getResources().getColor(R.color.black));
        b.setBackgroundTintList(getApplicationContext().getResources().getColorStateList(R.color.teal_700));
        b.setTextColor(getResources().getColor(R.color.white));
    }
}