package com.android_project.workassist;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

@SuppressWarnings("ALL")
public class SigninActivity extends AppCompatActivity {

    Button b_signup, b_c_signin, b_m_signin;
    TextView tv_signin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        tv_signin = findViewById(R.id.tv_signin);
        int id_bms=R.id.b_member_signin, id_bcs=R.id.b_customer_signin;

        b_m_signin = findViewById(id_bms);
        b_c_signin = findViewById(id_bcs);

        b_m_signin.setOnClickListener(view -> changeSignin(b_m_signin, b_c_signin));

        b_c_signin.setOnClickListener(view -> changeSignin(b_c_signin, b_m_signin));

        b_signup = findViewById(R.id.b_signup);
        b_signup.setOnClickListener(view -> {
            Intent i = new Intent(getApplicationContext(),SignupActivity.class);
            startActivity(i);
        });
    }

    @SuppressLint({"SetTextI18n", "UseCompatLoadingForColorStateLists"})
    public void changeSignin(Button a, Button b){
        if(a==findViewById(R.id.b_customer_signin))
            tv_signin.setText("Customer's SignIn");
        else
            tv_signin.setText("Member's SignIn");

        a.setBackgroundTintList(getApplicationContext().getResources().getColorStateList(R.color.teal_200));
        a.setTextColor(getResources().getColor(R.color.black));
        b.setBackgroundTintList(getApplicationContext().getResources().getColorStateList(R.color.teal_700));
        b.setTextColor(getResources().getColor(R.color.white));
    }
}